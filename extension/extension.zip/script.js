var cat = document.getElementById("cat");
var yarn = document.getElementById("yarn");
var bowl = document.getElementById("bowl");

// get cat name and display it

chrome.storage.local.get('catName', function(result) {
  var catName = result.catName; // get the input from local storage
  if (catName) { // if the input exists
      document.getElementById("catName").innerHTML = catName; // display the input on the page
      document.getElementById('form').style.display = 'none' // hide the form
  }
});

document.getElementById('form').addEventListener('submit', function(event) {
event.preventDefault(); // prevent the form from submitting
// somewhere here is the check for the input - don't ask for the user input if it's already there
chrome.storage.local.get('input', function(result) {
  var input = result.input; // get the input from local storage
  if (!input) { // if the input does not exist
    input = document.getElementById('input').value; // get the user's input from the form
  }
  chrome.storage.local.set({'catName': input}, function() { // save the input to local storage
  console.log('Thank you for naming me!');
  document.getElementById('form').style.display = 'none'; // hide the form
  });
});
});

// check if hearts exist in local storage
let hearts = 0;

// When the window loads, check the number of hearts in local storage
window.onload = function() {
  if (localStorage.getItem("hearts")) {
    if (localStorage.getItem("hearts") > 5) {
      localStorage.setItem("hearts", 5);
    }
    hearts = Number(localStorage.getItem("hearts"));
  }
  // Update the display with the correct number of hearts
  updateHeartsDisplay();
};

// Update the display with the correct number of hearts

function updateHeartsDisplay() {
  // Clear the current hearts display
  document.getElementById("score").innerHTML = "";
  // Add the correct number of hearts to the display
  for (let i = 0; i < hearts; i++) {
    const heart = document.createElement("img");
    heart.classList.add("heart");
    heart.setAttribute("data-added-time", Date.now());
    document.getElementById("score").appendChild(heart);
  }
}

// create counter for hearts

function addHeart() {
  if (hearts < 5) {
  hearts += 1;
  localStorage.setItem("hearts", hearts);
  // Create a new img element
  const heart = document.createElement("div");
  // Set its class to "heart"
  heart.classList.add("heart");
  // Set the time when the heart was added
  heart.setAttribute("data-added-time", Date.now());
  // Append it to the score element
  document.getElementById("score").appendChild(heart);
  // set timer to remove hearts after a while
  }
}

// set removeHeart function

function removeHeart() {
  hearts -= 1;
  localStorage.setItem("hearts", hearts);
  // Get the first child (heart) of the score element
  const heart = document.getElementById("score").firstChild;
  // Remove it from the score element
  document.getElementById("score").removeChild(heart);
  //remove timer
}

// Remove hearts that have been in the display for more than 16 hours

setInterval(function() {
  // Get all the hearts in the display
  const heartsElements = document.getElementsByClassName("heart");
  // Loop through the hearts
  for (let i = 0; i < heartsElements.length; i++) {
    // Get the time when the heart was added
    const addedTime = heartsElements[i].getAttribute("data-added-time");
    // Calculate the interval between the current time and the time when the heart was added
    const interval = Date.now() - addedTime;
    // If the interval is more than 16 hours (57600000 milliseconds)
    if (interval > 432000) {
      // Remove the heart
      removeHeart(heartsElements[i]);
    }
  }
}, 10000);

// display sad message if hearts are depleted
//if (hearts == 0) {
//  alert("You're making me sad - come play again. :(");

// add event listeners for the different clicks

cat.addEventListener("click", purr);
bowl.addEventListener("click", feed);
yarn.addEventListener("click", play);


// functions to enable animations

function play(){  
    yarn.classList.add("play");
    cat.classList.add("push");
    yarn.addEventListener("animationend", function() {
      yarn.classList.remove("play");
    });
    cat.addEventListener("animationend", function() {
      cat.classList.remove("push");
    });
    addHeart();
    console.log('Again! Again!');
}

function feed(){
    cat.classList.add("eat");
    cat.addEventListener("animationend", function() {
      cat.classList.remove("eat");
    });
    addHeart();
    console.log('Yum!');
}

function purr(){
    cat.classList.add("purr");
    cat.addEventListener("animationend", function() {
      cat.classList.remove("purr");
    });
    addHeart();
    console.log('Purr');
}